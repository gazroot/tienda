/*
 * CONFIGURACIÓN DE SUPABASE PARA AURA // NØIR
 * Reemplaza estos dos valores por los de tu proyecto: Supabase > Project Settings > API.
 * En el navegador solo se debe usar la clave publicable/anon. NUNCA pegues la service_role key aquí.
 */
const SUPABASE_URL = "PEGA_AQUI_TU_PROJECT_URL";
const SUPABASE_ANON_KEY = "PEGA_AQUI_TU_PUBLISHABLE_O_ANON_KEY";

if (!window.supabase) {
  console.error("No se cargó la librería de Supabase.");
} else if (SUPABASE_URL.startsWith("PEGA_AQUI") || SUPABASE_ANON_KEY.startsWith("PEGA_AQUI")) {
  console.warn("Configura SUPABASE_URL y SUPABASE_ANON_KEY en supabase-config.js.");
} else {
  window.auraSupabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
}
